export const sections = {
  hero: 'hero',
  services: 'services',
  contentStrategy: 'content-strategy',
  about: 'about',
  aiInnovation: 'ai-innovation-news',
  contact: 'contact',
  caseStudies: 'case-studies'
} as const;